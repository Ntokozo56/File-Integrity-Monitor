package fim.comparison;

import fim.model.FileRecord;
import fim.model.ScanResult;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileComparator {

    public ScanResult compare(
            Map<String, FileRecord> baseline,
            List<FileRecord> currentFiles) {

        ScanResult result = new ScanResult();

        Map<String, FileRecord> currentMap =
                new HashMap<>();

        for (FileRecord record : currentFiles) {
            currentMap.put(record.getFilePath(), record);
        }

        for (FileRecord current : currentFiles) {
            String path = current.getFilePath();

            if (!baseline.containsKey(path)) {

                result.addNew(current);
            } else {

                FileRecord old = baseline.get(path);

                if (old.getHash().equals(current.getHash())) {

                    result.addUnchanged(current);

                } else {

                    result.addModified(current);
                }
            }
        }
        for (FileRecord old : baseline.values()) {

            if (!currentMap.containsKey(old.getFilePath())) {

                result.addDeleted(old);
            }
        }

        return result;
    }
}