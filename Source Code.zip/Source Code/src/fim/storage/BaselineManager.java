package fim.storage;

import fim.model.FileRecord;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class BaselineManager {

    public void saveBaseline( Map<String, FileRecord> baseline, File file) 
            throws IOException {

        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file))) {

            output.writeObject(baseline);
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, FileRecord> loadBaseline(File file)
            
            throws IOException, ClassNotFoundException {

        if (!file.exists()) {

            throw new FileNotFoundException("Baseline file does not exist.");
        }

        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(file))) {

            Object object = input.readObject();
            if (!(object instanceof Map)) {

                throw new IOException("Invalid baseline format.");
            }

            return (Map<String, FileRecord>) object;
        }
    }

    public Map<String, FileRecord> createMap(
            java.util.List<FileRecord> records) {

        Map<String, FileRecord> map =
                new HashMap<>();

        for (FileRecord record : records) {
            map.put(record.getFilePath(), record);
        }

        return map;
    }
}