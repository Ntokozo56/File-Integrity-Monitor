package fim.gui;
import fim.model.ScanResult;
import fim.reporting.ReportGenerator;
import fim.service.IntegrityService;
import javax.swing.*;
import java.awt.*;
import java.io.File;

public class FileIntegrityGUI extends JFrame {

    private final IntegrityService service;
    private final ReportGenerator reportGenerator;
    private File selectedDirectory;
    private final JTextField directoryField;
    private final JTextArea resultArea;

    public FileIntegrityGUI(
            IntegrityService service) {
        this.service = service;
        this.reportGenerator =
                new ReportGenerator();
        setTitle( "File Integrity Monitor");

        setSize(800, 600);
        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        directoryField = new JTextField();
        directoryField.setEditable(false);
        resultArea =  new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 14));

        buildInterface();
    }

    private void buildInterface() {

        JPanel topPanel =
                new JPanel(new BorderLayout(10, 10));
        JButton browseButton =
                new JButton("Browse");
        browseButton.addActionListener(
                e -> chooseDirectory());
        topPanel.add(
                new JLabel("Protected Folder:"),
                BorderLayout.WEST);
        topPanel.add(
                directoryField,
                BorderLayout.CENTER);

        topPanel.add(browseButton, BorderLayout.EAST);
        JButton baselineButton =
                new JButton("Create Baseline");
        baselineButton.addActionListener(
                e -> createBaseline());
        JButton checkButton =
                new JButton( "Check Integrity");
        checkButton.addActionListener(
                e -> checkIntegrity());
        JButton saveReportButton =
                new JButton("Save Report");
        saveReportButton.addActionListener(
                e -> saveReport());
        JButton clearButton =
                new JButton("Clear");

        clearButton.addActionListener(
                e -> resultArea.setText(""));
        JPanel buttons =
                new JPanel(
                        new FlowLayout());
        buttons.add(baselineButton);
        buttons.add(checkButton);
        buttons.add(saveReportButton);
        buttons.add(clearButton);

        JPanel north = new JPanel(new BorderLayout());
        north.add(topPanel,BorderLayout.NORTH);
        north.add(buttons, BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);

        add(new JScrollPane(resultArea), BorderLayout.CENTER);
    }

    private void chooseDirectory() {

        JFileChooser chooser =
                new JFileChooser();
        chooser.setFileSelectionMode(
                JFileChooser.DIRECTORIES_ONLY);
        int result =
                chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {

            selectedDirectory = chooser.getSelectedFile();

            directoryField.setText(selectedDirectory.getAbsolutePath());
        }
    }

    private void createBaseline() {

        if (!validateDirectory()) {
            return;
        }

        try {
            service.createParallelBaseline(
                    selectedDirectory);

            File baseline =
                    new File(
                            "data/baseline.dat");

            service.saveBaseline(baseline);

            resultArea.setText("BASELINE CREATED\n\n" + "Directory:\n" + selectedDirectory.getAbsolutePath()+ "\n\n" + "Files recorded: " + service .getBaseline().size());
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void checkIntegrity() {

        if (!validateDirectory()) {
            return;
        }

        try {

            ScanResult result = service.checkIntegrity( selectedDirectory);

            String report = reportGenerator.generateReport(result);

            resultArea.setText(report);

        } catch (Exception e) {

            showError(e.getMessage());
        }
    }

    private void saveReport() {

        if (service.getLastResult() == null) {

            showError(
                    "Please run an integrity check first.");

            return;
        }

        try {

            String report = reportGenerator.generateReport( service.getLastResult());

            File file = new File("reports/integrity-report.txt");

            reportGenerator.saveReport(report,file);
            JOptionPane.showMessageDialog(this,"Report saved to:\n"+ file.getAbsolutePath(),"Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {

            showError(e.getMessage());
        }
    }

    private boolean validateDirectory() {

        if (selectedDirectory == null) {

            showError("Please select a directory.");

            return false;
        }

        return true;
    }

    private void showError(String message) {

        JOptionPane.showMessageDialog(this, message,"Error", JOptionPane.ERROR_MESSAGE);
    }
}