package fim.logging;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class ApplicationLogger {

    private static final Logger LOGGER = Logger.getLogger("FileIntegrityMonitor");

    static {
        try {

            File logDirectory = new File("logs");

            if (!logDirectory.exists()) {
                logDirectory.mkdirs();
            }

            FileHandler handler =new FileHandler( "logs/application.log", true);

            handler.setFormatter(new SimpleFormatter());

            LOGGER.addHandler(handler);

            LOGGER.setLevel(Level.ALL);

            LOGGER.setUseParentHandlers(false);

        } catch (IOException e) {

            System.err.println("Could not initialize logger: " + e.getMessage());
        }
    }

    public static void info(String message) {
        LOGGER.info(message);
    }

    public static void warning(String message) {
        LOGGER.warning(message);
    }

    public static void error(String message) {
        LOGGER.severe(message);
    }
}