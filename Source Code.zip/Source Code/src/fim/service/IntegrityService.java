package fim.service;

import fim.comparison.FileComparator;
import fim.hashing.Hasher;
import fim.logging.ApplicationLogger;
import fim.model.FileRecord;
import fim.model.ScanResult;
import fim.scanner.FileScanner;
import fim.storage.BaselineManager;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IntegrityService {

    private final FileScanner scanner;
    private final FileComparator comparator;
    private final BaselineManager baselineManager;

    private Map<String, FileRecord> baseline;

    private ScanResult lastResult;

    public IntegrityService(Hasher hasher) {

        scanner = new FileScanner(hasher);
        comparator = new FileComparator();
        baselineManager = new BaselineManager();

        baseline = new HashMap<>();
    }

    public Map<String, FileRecord> createBaseline(
            File directory) {

        validateDirectory(directory);

        ApplicationLogger.info(
                "Creating baseline for: "
                + directory.getAbsolutePath());

        List<FileRecord> records = scanner.scan(directory);

        baseline = baselineManager.createMap(records);

        ApplicationLogger.info("Baseline created. Files: " + baseline.size());

        return baseline;
    }

    public Map<String, FileRecord> createParallelBaseline(
            File directory)
            throws InterruptedException {

        validateDirectory(directory);

        ApplicationLogger.info(
                "Creating parallel baseline.");

        List<FileRecord> records = scanner.scanParallel(directory);

        baseline = baselineManager.createMap(records);

        return baseline;
    }

    public ScanResult checkIntegrity(
            File directory) {

        validateDirectory(directory);

        if (baseline.isEmpty()) {

            throw new IllegalStateException("No baseline loaded. Create or load a baseline first.");
        }

        ApplicationLogger.info("Integrity check started.");

        List<FileRecord> currentFiles =  scanner.scan(directory);

        lastResult = comparator.compare(baseline, currentFiles);

        ApplicationLogger.info("Integrity check completed.");

        return lastResult;
    }

    public void saveBaseline(File file)
            throws Exception {

        baselineManager.saveBaseline(baseline, file);

        ApplicationLogger.info( "Baseline saved to " + file.getAbsolutePath());
    }

    public void loadBaseline(File file)
            throws Exception {

        baseline = baselineManager.loadBaseline(file);

        ApplicationLogger.info("Baseline loaded. Files: "  + baseline.size());
    }

    public Map<String, FileRecord> getBaseline() {
        return baseline;
    }

    public ScanResult getLastResult() {
        return lastResult;
    }

    private void validateDirectory(File directory) {

        if (directory == null) {

            throw new IllegalArgumentException("Directory cannot be null.");
        }

        if (!directory.exists()) {

            throw new IllegalArgumentException("Directory does not exist.");
        }

        if (!directory.isDirectory()) {

            throw new IllegalArgumentException("Selected path is not a directory.");
        }
    }
}