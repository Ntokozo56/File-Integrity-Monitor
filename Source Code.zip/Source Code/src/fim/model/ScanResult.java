package fim.model;

import java.util.ArrayList;
import java.util.List;

public class ScanResult {

    private final List<FileRecord> unchangedFiles = new ArrayList<>();
    private final List<FileRecord> modifiedFiles = new ArrayList<>();
    private final List<FileRecord> newFiles = new ArrayList<>();
    private final List<FileRecord> deletedFiles = new ArrayList<>();

    public void addUnchanged(FileRecord file) {
        unchangedFiles.add(file);
    }

    public void addModified(FileRecord file) {
        modifiedFiles.add(file);
    }

    public void addNew(FileRecord file) {
        newFiles.add(file);
    }

    public void addDeleted(FileRecord file) {
        deletedFiles.add(file);
    }

    public List<FileRecord> getUnchangedFiles() {
        return unchangedFiles;
    }

    public List<FileRecord> getModifiedFiles() {
        return modifiedFiles;
    }

    public List<FileRecord> getNewFiles() {
        return newFiles;
    }

    public List<FileRecord> getDeletedFiles() {
        return deletedFiles;
    }

    public int getTotalChanges() {
        return modifiedFiles.size()
                + newFiles.size()
                + deletedFiles.size();
    }

    public boolean hasChanges() {
        return getTotalChanges() > 0;
    }
}