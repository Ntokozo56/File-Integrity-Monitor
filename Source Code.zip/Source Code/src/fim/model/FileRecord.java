
package fim.model;
import java.io.Serializable;

public class FileRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String filePath;
    private final String fileName;
    private final long fileSize;
    private final long lastModified;
    private final String hash;

    public FileRecord(String filePath, String fileName, long fileSize, long lastModified, String hash) {

        this.filePath = filePath;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.lastModified = lastModified;
        this.hash = hash;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public long getLastModified() {
        return lastModified;
    }

    public String getHash() {
        return hash;
    }

    @Override
    public String toString() {
        return fileName + " | " + filePath + " | " + hash;
    }
}