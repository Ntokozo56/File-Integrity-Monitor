package fim.scanner;

import fim.hashing.Hasher;
import fim.model.FileRecord;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class FileScanner {

    private final Hasher hasher;

    public FileScanner(Hasher hasher) {
        this.hasher = hasher;
    }

    public List<File> findFiles(File directory) {

        List<File> files = new ArrayList<>();

        if (directory == null || !directory.exists()) {
            return files;
        }

        if (directory.isFile()) {
            files.add(directory);
            return files;
        }

        File[] children = directory.listFiles();

        if (children == null) {
            return files;
        }

        for (File child : children) {

            if (child.isDirectory()) {

                files.addAll(findFiles(child));

            } else if (child.isFile()) {

                files.add(child);
            }
        }

        return files;
    }


    public List<FileRecord> scan(File directory) {

        List<File> files = findFiles(directory);
        List<FileRecord> records = new ArrayList<>();

        for (File file : files) {

            try {

                FileRecord record = createRecord(file);

                if (record != null) {
                    records.add(record);
                }

            } catch (IOException e) {

                System.err.println(
                        "Could not read: " + file.getAbsolutePath());
            }
        }

        return records;
    }

 
    public List<FileRecord> scanParallel(File directory)
            throws InterruptedException {

        List<File> files = findFiles(directory);

        if (files.isEmpty()) {
            return new ArrayList<>();
        }

        int threadCount = Math.min( Runtime.getRuntime().availableProcessors(),files.size());

        ExecutorService executor = Executors.newFixedThreadPool(threadCount);

        List<Callable<FileRecord>> tasks = new ArrayList<>();

        for (File file : files) {

            tasks.add(() -> {

                try {
                    return createRecord(file);

                } catch (IOException e) {

                    System.err.println("Could not hash: "+ file.getAbsolutePath());

                    return null;
                }
            });
        }

        List<FileRecord> records = new ArrayList<>();

        try {

            List<Future<FileRecord>> futures = executor.invokeAll(tasks);
            for (Future<FileRecord> future : futures) {

                try {
                    FileRecord record = future.get();

                    if (record != null) {
                        records.add(record);
                    }

                } catch (ExecutionException e) {

                    System.err.println("Hashing task failed: "+ e.getMessage());
                }
            }

        } finally {

            executor.shutdown();
        }

        return records;
    }

    private FileRecord createRecord(File file)
            throws IOException {

        String hash = hasher.generateHash(file);

        return new FileRecord(file.getCanonicalPath(), file.getName(), file.length(), file.lastModified(), hash);
    }
}