package fim.reporting;

import fim.model.FileRecord;
import fim.model.ScanResult;

import java.io.*;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ReportGenerator {

    public String generateReport(ScanResult result) {

        StringBuilder report = new StringBuilder();

        report.append("\n");
        report.append("========================================\n");
        report.append("       FILE INTEGRITY REPORT\n");
        report.append("========================================\n");

        report.append("Generated: ")
                .append(LocalDateTime.now())
                .append("\n\n");

        report.append("Unchanged: ")
                .append(result.getUnchangedFiles().size())
                .append("\n");

        report.append("Modified: ")
                .append(result.getModifiedFiles().size())
                .append("\n");

        report.append("New: ")
                .append(result.getNewFiles().size())
                .append("\n");

        report.append("Deleted: ")
                .append(result.getDeletedFiles().size())
                .append("\n");

        appendSection(
                report,
                "MODIFIED FILES",
                result.getModifiedFiles());

        appendSection(
                report,
                "NEW FILES",
                result.getNewFiles());

        appendSection(
                report,
                "DELETED FILES",
                result.getDeletedFiles());

        return report.toString();
    }

    private void appendSection(
            StringBuilder report,
            String title,
            List<FileRecord> files) {

        report.append("\n");
        report.append("----- ")
                .append(title)
                .append(" -----\n");

       
        List<FileRecord> sorted =
                files.stream()
                        .sorted(
                                Comparator.comparing(
                                        FileRecord::getFileName))
                        .collect(Collectors.toList());

        if (sorted.isEmpty()) {

            report.append("None\n");

        } else {

            for (FileRecord file : sorted) {

                report.append(file.getFileName())
                        .append("\n");

                report.append("Path: ")
                        .append(file.getFilePath())
                        .append("\n");

                report.append("Hash: ")
                        .append(file.getHash())
                        .append("\n\n");
            }
        }
    }
    public void saveReport(
            String report,
            File file) throws IOException {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (BufferedWriter writer =
                new BufferedWriter(
                        new FileWriter(file))) {
            writer.write(report);
        }
    }
}