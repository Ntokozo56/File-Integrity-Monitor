package fim.hashing;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SHA256Hasher implements Hasher {

    private static final int BUFFER_SIZE = 8192;

    @Override
    public String generateHash(File file) throws IOException {

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            try (BufferedInputStream input =new BufferedInputStream( new FileInputStream(file))) {

                byte[] buffer = new byte[BUFFER_SIZE];
                int bytesRead;
                while ((bytesRead = input.read(buffer)) != -1) {
                    digest.update(buffer, 0, bytesRead);
                }
            }

            return bytesToHex(digest.digest());
        } catch (NoSuchAlgorithmException e) {

            throw new IOException("SHA-256 algorithm is not available.", e);
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();

        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }

        return result.toString();
    }
}