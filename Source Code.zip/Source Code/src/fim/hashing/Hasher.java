
package fim.hashing;

import java.io.File;
import java.io.IOException;

public interface Hasher {

    String generateHash(File file) throws IOException;
}