package fim;
import fim.cli.ConsoleMenu;
import fim.gui.FileIntegrityGUI;
import fim.hashing.SHA256Hasher;
import fim.service.IntegrityService;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        IntegrityService service =
                new IntegrityService(
                        new SHA256Hasher());
        System.out.println(
                "======================================");
        System.out.println(
                "       FILE INTEGRITY MONITOR");
        System.out.println(
                "======================================");
        System.out.println();
        System.out.println(
                "1. Command Line Interface");
        System.out.println(
                "2. Graphical User Interface");
        java.util.Scanner scanner =
                new java.util.Scanner(System.in);

        System.out.print(
                "\nChoose interface: ");
        String choice =
                scanner.nextLine();
        if (choice.equals("1")) {

            ConsoleMenu menu =
                    new ConsoleMenu(service);
            menu.start();
        } else if (choice.equals("2")) {
            SwingUtilities.invokeLater(() -> {
                FileIntegrityGUI gui =
                        new FileIntegrityGUI(service);
                gui.setVisible(true);
            });
        } else {
            System.out.println(
                    "Invalid choice.");
        }
    }
}