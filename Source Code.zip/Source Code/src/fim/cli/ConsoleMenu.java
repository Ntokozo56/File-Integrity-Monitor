package fim.cli;

import fim.logging.ApplicationLogger;
import fim.model.ScanResult;
import fim.reporting.ReportGenerator;
import fim.service.IntegrityService;
import java.io.File;
import java.util.Scanner;

public class ConsoleMenu {

    private final IntegrityService service;
    private final Scanner scanner;
    private final ReportGenerator reportGenerator;

    private File selectedDirectory;

    public ConsoleMenu(IntegrityService service) {

        this.service = service;
        this.scanner = new Scanner(System.in);
        this.reportGenerator = new ReportGenerator();
    }

    public void start() {

        boolean running = true;

        while (running) {

            displayMenu();

            String option = scanner.nextLine();

            switch (option) {

                case "1":
                    selectDirectory();
                    break;

                case "2":
                    createBaseline();
                    break;

                case "3":
                    loadBaseline();
                    break;

                case "4":
                    checkIntegrity();
                    break;

                case "5":
                    showLastReport();
                    break;

                case "6":
                    saveReport();
                    break;

                case "7":
                    running = false;
                    System.out.println(
                            "\nApplication closed.");
                    break;

                default:
                    System.out.println(
                            "\nInvalid option.");
            }
        }
    }

    private void displayMenu() {

        System.out.println();
        System.out.println(
                "=======================================");
        System.out.println(
                "       FILE INTEGRITY MONITOR");
        System.out.println(
                "=======================================");

        System.out.println(
                "Selected directory: "
                + (selectedDirectory == null
                    ? "None"
                    : selectedDirectory.getAbsolutePath()));

        System.out.println();
        System.out.println("1. Select directory");
        System.out.println("2. Create baseline");
        System.out.println("3. Load baseline");
        System.out.println("4. Check integrity");
        System.out.println("5. View last report");
        System.out.println("6. Save report");
        System.out.println("7. Exit");

        System.out.print("\nEnter option: ");
    }

    private void selectDirectory() {
        System.out.print("\nEnter directory path: ");

        String path = scanner.nextLine();
        File directory = new File(path);
        if (!directory.exists()
                || !directory.isDirectory()) {
            System.out.println(
                    "Invalid directory.");
            return;
        }

        selectedDirectory = directory;
        System.out.println("Directory selected successfully.");
    }

    private void createBaseline() {
        if (!checkDirectorySelected()) {
            return;
        }
        try {
            service.createParallelBaseline(selectedDirectory);

            File baselineFile = new File("data/baseline.dat");

            service.saveBaseline(baselineFile);
            System.out.println( "\nBaseline created successfully.");
            System.out.println("Files recorded: "+ service.getBaseline().size());

        } catch (Exception e) {
            ApplicationLogger.error(e.getMessage());
            System.out.println( "Error: " + e.getMessage());
        }
    }
    private void loadBaseline() {

        try {

            File file =  new File("data/baseline.dat");

            service.loadBaseline(file);
            System.out.println("\nBaseline loaded.");

            System.out.println( "Files: "+ service.getBaseline().size());

        } catch (Exception e) {

            System.out.println("Could not load baseline: " + e.getMessage());
        }
    }

    private void checkIntegrity() {

        if (!checkDirectorySelected()) {
            return;
        }
        try {

            ScanResult result = service.checkIntegrity(selectedDirectory);

            String report =reportGenerator.generateReport(result);
            System.out.println(report);

        } catch (Exception e) {

            System.out.println( "Error: "+ e.getMessage());
        }
    }

    private void showLastReport() {

        if (service.getLastResult() == null) { 
            System.out.println( "\nNo scan has been performed.");

            return;
        }

        System.out.println(reportGenerator.generateReport(service.getLastResult()));
    }

    private void saveReport() {

        if (service.getLastResult() == null) {
            System.out.println("\nNo report available.");

            return;
        }

        try {
            String report =
                    reportGenerator.generateReport(
                            service.getLastResult());

            File file = new File( "reports/integrity-report.txt");
            reportGenerator.saveReport( report, file);

            System.out.println("\nReport saved to:");
            System.out.println( file.getAbsolutePath());
        } catch (Exception e) {
            System.out.println("Could not save report: " + e.getMessage());
        }
    }
    private boolean checkDirectorySelected() {
        if (selectedDirectory == null) {

            System.out.println( "\nPlease select a directory first.");
            return false;
        }

        return true;
    }
}